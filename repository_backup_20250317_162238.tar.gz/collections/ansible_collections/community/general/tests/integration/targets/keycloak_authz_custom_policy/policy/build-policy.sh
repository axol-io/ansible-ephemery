#!/bin/sh
zip -r policy.jar META-INF/keycloak-scripts.json policy-1.js policy-2.js
